#!/bin/bash

echo "true"
exit 0 # success
